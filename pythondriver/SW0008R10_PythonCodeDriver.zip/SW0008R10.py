#!/usr/bin/python
import serial
import binascii

# Python eg code to read L201 temperatures
# SW0008 Revision 1.0
# Rugged Monitoring

# User must configure these two values correctly
SerialPort = 'COM3'                 # Serial Port on on which the native board is connected
                                    # ex: COM3 or /dev/ttyS0 or /dev/ttyUSB0
ConfiguredTemperatureChannels = 5   # No of temperature channels configured in the native board

# Following function computes the CRC on the given byte array
def fnGetCRC(btArray):
    crc = 0
    for x in btArray:
        crc = crc ^ (x * 256)
        for y in range(8):
            if crc > 0x7FFF:
                crc = (crc * 2) ^ 0x8005
                crc &= 0xFFFF
            else:
                crc = crc * 2
    return crc

# Request and Response byte arrays
request = bytearray()
response = bytearray()


# Fill in the request array
request.append(0x7B)            # SOC - Start of command ID
request.append(0x20)            # Command ID to get Temperature Data
request.append(0x00)            # always 0
request.append(0x00)            # ack request. keep it 0
request.append(0x00)            # id
crc = fnGetCRC(request)
high, low = divmod(crc, 0x100)
request.append(high)            # CRC high byte 0x95
request.append(low)             # CRC low  byte 0xC4
request.append(0x7D)

# Compute response length
nExpectedResponseLen = 8 + (ConfiguredTemperatureChannels * 8) + 8 # header + payload + footer


# Open the serial port
ser = serial.Serial(SerialPort,115200, timeout=5)

# Write request data to serial port
ser.write(request)
print("request  >> %s" % binascii.hexlify(request).upper())

# Read response data from serial port
while True:
    respbyte = ser.read()
    if len(respbyte) == 0:
        break
    response.append(ord(respbyte))
    if len(response) >= nExpectedResponseLen:
        break

# print out the sent and received byte streams
print("response << %s" % binascii.hexlify(response).upper())
print("")

# compute the CRC of the just payload bytes (all bytes excluding first 8 header bytes and last 8 footer bytes)
crc_computed = fnGetCRC(response[8:nExpectedResponseLen-8])
#high, low  = divmod(crc, 0x100)
crc_received = response[nExpectedResponseLen-3] * 256 + response[nExpectedResponseLen-2]
#print 'Computed and Received CRCs = 0x%04X 0x%04X' % (crc, crc2)

if crc_computed != crc_received:
    print("error - CRC mismatch!!!!")
    exit(0)

for k in range(ConfiguredTemperatureChannels):
    nValue = response[8 + 0 + (k * 8)]
    print("Channel #%u Status Value = 0x%02X (%d)" % (k, nValue, nValue))

    nValue = response[8 + 1 + (k * 8)]
    print("Channel #%u Gain Value = 0x%02X (%d)" % (k, nValue, nValue))

    nValue = response[8 + 2 + (k * 8)]
    print("Channel #%u Signal Strength Value = 0x%02X (%d)" % (k, nValue, nValue))

    nValue = response[8 + 5 + (k * 8)] * 256 + response[8 + 4 + (k * 8)]
    print("Channel #%u Amplitude Value = 0x%04X (%d)" % (k, nValue, nValue))

    nValue = response[8 + 7 + (k * 8)] * 256 +  response[8 + 6 + (k * 8)]
    print("Channel #%u Temperature Value = 0x%04X (%d)" % (k, nValue, nValue))

    print("")


